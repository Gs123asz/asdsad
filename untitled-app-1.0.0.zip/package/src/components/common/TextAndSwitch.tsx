import React from "react";

import { green, red } from "@mui/material/colors";
import { withStyles, Switch, Grid, Typography } from "@mui/material";
import { isDarkTheme } from "../../Theme";


interface TextAndSwitchProps {
  readonly label: string;
  readonly checked: boolean;
  readonly onClick?: () => void;
}

export const TextAndSwitchGreen = (props: TextAndSwitchProps): JSX.Element => (
  <Grid
    container
    direction="row"
    alignItems="center"
    justifyContent="space-between"
    wrap="nowrap"
  >
    <Typography
      variant="h6"
      style={{ color: isDarkTheme() ? "white" : "black" }}
    >
      {props.label}
    </Typography>
    <Switch
      color={"success"}
      checked={props.checked}
      onClick={props.onClick}
    />
  </Grid>
);

export const TextAndSwitchRed = (props: TextAndSwitchProps): JSX.Element => (
  <Grid
    container
    direction="row"
    alignItems="center"
    justifyContent="space-between"
    wrap="nowrap"
  >
    <Typography
      variant="h6"
      style={{ color: isDarkTheme() ? "white" : "black" }}
    >
      {props.label}
    </Typography>
    <Switch color="error" checked={props.checked} onClick={props.onClick} />
  </Grid>
);