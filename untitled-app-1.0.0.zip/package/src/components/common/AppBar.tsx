import React from "react";
import {
  AppBar as MaterialAppBar,
  Typography,
  Toolbar,
} from "@mui/material";

import Menu from "./Menu";
import { Tab } from "./Menu";

interface AppBarProps {
  readonly setTab: (tab: Tab) => void;
}

const AppBar = (props: AppBarProps): JSX.Element => {
  return (
    <MaterialAppBar color="secondary"  enableColorOnDark>
      <Toolbar >
        <Menu setTab={props.setTab} />
        <Typography variant="h6" color="white">
            Location App
        </Typography>
      </Toolbar>
    </MaterialAppBar>
  );
};

export default AppBar;