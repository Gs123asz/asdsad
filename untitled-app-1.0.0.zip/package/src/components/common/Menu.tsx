import React from "react";

import {
  Drawer,
  List,
  ListItem,
  ListItemText,
  ListItemIcon,
  SvgIconTypeMap,
  IconButton,
  Icon,
  Typography,
  Divider
} from "@mui/material";

import HomeIcon from "@mui/icons-material/Home";
import SettingsIcon from "@mui/icons-material/Settings";
import AssistantDirectionIcon from '@mui/icons-material/AssistantDirection';
import { useToggle } from "../../utils/Hooks";
import { isDarkTheme } from "../../Theme";

export enum Tab {
  Home = "Home",
  Settings = "Settings",
}

interface MenuProps {
  readonly setTab: (tab: Tab) => void;
}

const menuList: [Tab, typeof Icon][] = [
  [Tab.Home, HomeIcon],
  [Tab.Settings, SettingsIcon],
];

const Menu = (props: MenuProps): JSX.Element => {
  const [menuOpened, toggleMenu] = useToggle();

  return (
    <>
      <IconButton edge="start" onClick={toggleMenu}>
        <AssistantDirectionIcon htmlColor="#ffff" />
      </IconButton>

      <Drawer anchor="left" open={menuOpened} onClose={toggleMenu}>
        <List>
            <ListItem>
                <Typography variant="subtitle1" textAlign="center" width="100%" color={isDarkTheme() ? "white" : "black"}>
                    Location App
                
                </Typography>
                
            </ListItem>
            <ListItem>
                <Divider style={{"width":"100%"}}/>
            </ListItem>
          {menuList.map(
            ([tab, Icon], index: number): JSX.Element => (
              <ListItem
                button
                onClick={(): void => {
                  toggleMenu();
                  props.setTab(tab);
                }}
                key={index}
              >
                <ListItemIcon>
                  <Icon />
                </ListItemIcon>
                <ListItemText primary={tab} />
              </ListItem>
            )
          )}
        </List>
      </Drawer>
    </>
  );
};

export default Menu;