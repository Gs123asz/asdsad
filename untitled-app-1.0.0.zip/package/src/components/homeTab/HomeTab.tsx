import React from "react";

import { Grid, Box } from "@mui/material"

import FirstRow from "./layout/FirstRow";



const HomeTab = (): JSX.Element => {
  return (
    <Box marginY={2} width={1} height="100vh" marginX={1}>
      <Grid container direction="column">
        <Grid item>
          <FirstRow />
        </Grid>
        <Grid item>
          
        </Grid>
      </Grid>
    </Box>
  );
};

export default HomeTab;