import React, { useState, useRef } from "react";
import { Grid } from "@mui/material";
import MapCard from '../cards/MapCard'
import CoordinatsCard from '../cards/CordinatsCard'
import CoordinatListItem from '../common/CoordinatListItem'
import {
    Marker,
    Popup
} from 'react-leaflet'


const FirstRow = (): JSX.Element => {

    const [coords, setCoords] = useState([])
    const [coordsPolyArray, setCoordsPolyArray] = useState([[51.505, -0.09]])
    const [lastLocationMarker,setLastLocationMarker] = useState<any>(null)

    const addCoordinat = async (latitude : string | number,longitude : string | number,timeStemp : string | number, accuracy : string | number) => {
        setCoordsPolyArray(
            coordsPolyArray.concat(
                [
                    [
                        Number(latitude),Number(longitude)
                    ]
                ]
            )
        )
        await setCoords((pastList) =>[<CoordinatListItem key={timeStemp} latitude= {latitude} longitude={longitude} timeStemp={timeStemp} accuracy={accuracy} />,pastList])

        setLastLocationMarker(
            <Marker position={[Number(latitude),Number(longitude)]}>
                <Popup>
                    A pretty CSS3 popup. <br /> Easily customizable.
                </Popup>
            </Marker>
        )
    }
    const addCoordinats = async (arr : {latitude : string | number,longitude : string | number,timeStemp : string | number, accuracy : string | number}[]) => {

        setCoordsPolyArray(
            coordsPolyArray.concat(
                [
                ].concat(arr.map((value, index)=>{
                    return [
                        Number(value.latitude),Number(value.longitude)
                    ]
                }))
            )
        )
        const lastLocation= arr[arr.length -1]

        await setCoords((pastList) =>[<CoordinatListItem key={lastLocation.timeStemp} latitude= {lastLocation.latitude} longitude={lastLocation.longitude} timeStemp={lastLocation.timeStemp} accuracy={lastLocation.accuracy} />,pastList])

        setLastLocationMarker(
            <Marker position={[Number(lastLocation.latitude),Number(lastLocation.longitude)]}>
                <Popup>
                    A pretty CSS3 popup. <br /> Easily customizable.
                </Popup>
            </Marker>
        )
    }
    return(
        <Grid item container justifyContent="space-around" alignItems="flex-start">
            <Grid item xs={5}>
                <CoordinatsCard addCoordinats={addCoordinats} coords={coords} setCoords={setCoords} addCoordinat={addCoordinat}/>
            </Grid>
            <Grid item xs={6}>
                <MapCard coords={coordsPolyArray} lastLocationMarker={lastLocationMarker}/>
            </Grid>
        </Grid>
    )
};

export default FirstRow;