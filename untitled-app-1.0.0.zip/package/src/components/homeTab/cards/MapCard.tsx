import React, { Ref, useRef } from 'react'
import {
    Card,
    CardHeader,
    Typography,
    CardContent,
    Divider,
    CardActions
} from '@mui/material'

import {
    MapContainer,
    TileLayer,
    Marker,
    Popup,
    Polyline
} from 'react-leaflet'

import { isDarkTheme } from "../../../Theme";
import * as core from '@react-leaflet/core'
import L from 'leaflet';
import 'leaflet.fullscreen'

interface FullscreenOptions {
    content?: string | undefined;
    position?: L.ControlPosition | undefined;
    title?: string | undefined;
    titleCancel?: string | undefined;
    forceSeparateButton?: boolean | undefined;
    forcePseudoFullscreen?: boolean | undefined;
    pseudoFullscreen?: boolean | undefined;
    fullscreenElement?: false | HTMLElement | undefined;
}

const FullscreenControl = core.createControlComponent(
    (props : FullscreenOptions) => {
        return L.control.fullscreen(props)
    }
)

interface MapCardPropsInterface{
    readonly coords: any[]
    readonly lastLocationMarker : any

}
const limeOptions = { color: 'lime' }


const MapCard = (props : MapCardPropsInterface) : JSX.Element => {
    return (
        <Card variant="elevation" style={{"height":"81vh"}}>
            <CardContent>
                <h2 style={{"textAlign":"center"}}>
                    Route Map  
                </h2>
                <Divider/>
                <br />
                <MapContainer center={[51.505, -0.09]} zoom={13} style={{"height":"100%","width":"100%",minWidth:"500px",minHeight:"500px"}}>
                    <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    {props.lastLocationMarker}
                    <FullscreenControl />
                    {props.coords.length > 0 ?
                        <Polyline pathOptions={limeOptions} positions={props.coords} />
                        : 
                        <></>
                    }
                </MapContainer>
                
            </CardContent>
        </Card>
    )
}

export default MapCard