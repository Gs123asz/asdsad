import React,{useEffect, useState} from 'react'
import {
    Card,
    CardHeader,
    Typography,
    CardContent,
    Divider,
    ListItemAvatar,
    List,
    ListItem,
    ListItemText,
    Avatar,
    Grid,
} from '@mui/material'
import LocationOnIcon from '@mui/icons-material/LocationOn';

interface CoordinatsCardProps{
    readonly coords: any[]
    readonly setCoords: React.Dispatch<React.SetStateAction<any[]>>
    readonly addCoordinat : (latitude : string | number,longitude : string | number,timeStemp : string | number, accuracy : string | number) => void;
    readonly addCoordinats : (array : {latitude : string | number,longitude : string | number,timeStemp : string | number, accuracy : string | number}[]) => void;

}


const CoordinatsCard = (props : CoordinatsCardProps) => {
    useEffect(()=>{
        loadPastCordinats()
    },[])

    function delay(ms: number) {
        return new Promise( resolve => setTimeout(resolve, ms) );
    }
    const loadPastCordinats = async () => {

        for(let i = 0; i < 10; i++){
            await props.addCoordinats(
                [
                    {
                        latitude : 51.505 + ((i+1) * 0.001),
                        longitude : -0.09 + ((i+1) * 0.005),
                        timeStemp : Date.now(),
                        accuracy : 12
                    },
                    {
                        latitude : 51.505 + ((i+i-1) * 0.011),
                        longitude : -0.09 + ((i+i-1) * 0.005),
                        timeStemp : Date.now(),
                        accuracy : 12
                    },
                    {
                        latitude : 51.505 + ((i+1) * 0.021),
                        longitude : -0.09 + ((i+1) * 0.035),
                        timeStemp : Date.now(),
                        accuracy : 12
                    },
                    {
                        latitude : 51.505 + ((i+i+1) * 0.41),
                        longitude : -0.09 + ((i+i+1) * 0.05),
                        timeStemp : Date.now(),
                        accuracy : 12
                    },
                    {
                        latitude : 51.505 + ((i+1) * 0.001),
                        longitude : -0.09 + ((i+1) * 0.005),
                        timeStemp : Date.now(),
                        accuracy : 12
                    },
                    {
                        latitude : 51.505 + ((i+i+1) * 0.001),
                        longitude : -0.09 + ((i+i+1) * 0.005),
                        timeStemp : Date.now(),
                        accuracy : 12
                    }
                ]
            )
            await delay(200)
        }
    }


    return (
        <Card style={{"height":"81vh"}}>
            <CardContent style={{"height":"100%"}}>
                <h2 style={{"textAlign":"center"}}>
                    Coord's List
                </h2>
                <Divider/>
                <br />
                <List sx={{ width: '100%', overflowY:"auto", maxHeight:"78%", bgcolor: 'background.paper' }}>
                    {props.coords}
                </List>
            </CardContent>
        </Card>
    )
}

export default CoordinatsCard