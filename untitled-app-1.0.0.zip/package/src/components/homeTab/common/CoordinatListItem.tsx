import React,{useEffect, useState} from 'react'
import {
    Card,
    CardHeader,
    Typography,
    CardContent,
    Divider,
    ListItemAvatar,
    List,
    ListItem,
    ListItemText,
    Avatar,
    Grid,
} from '@mui/material'
import LocationOnIcon from '@mui/icons-material/LocationOn';

interface Cord{
    readonly latitude : string | number,
    readonly longitude : string | number,
    readonly timeStemp : string | number,
    readonly accuracy : string | number
}

const CoordinatListItem = (props : Cord) => {

    const fixedTimeStemp = (timeStemp : number | string) => {
        timeStemp = Number(timeStemp)
        const date = new Date(timeStemp)
        return `${date.getDay().toLocaleString('en-US', {
            minimumIntegerDigits: 2,
            useGrouping: false
          })}.${date.getMonth().toLocaleString('en-US', {
            minimumIntegerDigits: 2,
            useGrouping: false
          })}.${date.getFullYear() - 2000}    |   ${date.getHours().toLocaleString('en-US', {
            minimumIntegerDigits: 2,
            useGrouping: false
          })}:${date.getMinutes().toLocaleString('en-US', {
            minimumIntegerDigits: 2,
            useGrouping: false
          })}:${date.getSeconds().toLocaleString('en-US', {
            minimumIntegerDigits: 2,
            useGrouping: false
          })}`
    }
    return (
    <>
        <ListItem alignItems="flex-start" button >
            <ListItemAvatar style={{marginTop:24}}>
                <Avatar>
                    <LocationOnIcon/>
                </Avatar>
            </ListItemAvatar>
            < ListItemText 
                primary={
                    <Grid container item>
                        <Grid item xs={8}>
                            <Typography variant="body1">
                                New Location
                            </Typography>
                        </Grid>
                        <Grid item xs={4} style={{textAlign:"end"}}>
                            <Typography variant="caption">
                                {fixedTimeStemp(props.timeStemp)}
                            </Typography>
                        </Grid>
                    </Grid>
                }
                secondary={
                    <>
                        <span>
                            Latitude: {props.latitude}
                        </span>
                        <br />
                        <span>
                            Longitude: {props.longitude}
                        </span>
                        <br />
                        <span>
                            Accuracy: {props.accuracy}m
                        </span>
                    </>
                }
            />
                
        </ListItem>
        <Divider variant="inset" component="li" />
    </>
    )
} 

export default CoordinatListItem