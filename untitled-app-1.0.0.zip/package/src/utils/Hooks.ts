import { useState } from "react";

export const useToggle = (
    initialValue: boolean = false
  ): [boolean, () => void] => {
    const [toggle, setToggle] = useState(initialValue);
    const flip = (): void => setToggle((prev: boolean): boolean => !prev);
    return [toggle, flip];
};