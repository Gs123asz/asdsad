import React,{useEffect, useState} from "react";
import { useTheme, ThemeProvider, createTheme,Grid } from '@mui/material';
import { lightTheme, darkTheme  } from "./Theme";
import { useToggle } from "./utils/Hooks";
import { grey } from "@mui/material/colors";
import { Tab } from "./components/common/Menu";
import AppBar from "./components/common/AppBar";
import SettingsTab from "./components/settingsTab/SettingsTab";
import HomeTab from "./components/homeTab/HomeTab";

const App = () : JSX.Element => {
    const [isDarkTheme, toggleTheme] = useToggle();
    const [tab, setTab] = useState(Tab.Home);


    const [visibaleHomeTab,setVisibaleHomeTab] = useState(true)
    const [visibaleSettingsTab,setVisibaleSettingsTab] = useState(false)
    useEffect(()=>{
        switch (tab) {
            case Tab.Home:
              setVisibaleHomeTab(true)
              setVisibaleSettingsTab(false)
              return
            case Tab.Settings:
              setVisibaleHomeTab(false)
              setVisibaleSettingsTab(true)
              return
        }
    })

    return (
        <ThemeProvider theme={isDarkTheme ? darkTheme : lightTheme}>
            <AppBar setTab={setTab} />
            <Grid container style={{ position: "fixed", left: 0, top: 69, backgroundColor: isDarkTheme ? grey[900] : ""}} visibility={ visibaleHomeTab ? "visible" : "hidden"} >
                <HomeTab />
            </Grid>
            <Grid container style={{ position: "fixed", left: 0, top: 69, backgroundColor: isDarkTheme ? grey[900] : ""}} visibility={ visibaleSettingsTab ? "visible" : "hidden"} >
                <SettingsTab toggleTheme={toggleTheme}/>
            </Grid>
        </ThemeProvider>
    )
}

export default App;