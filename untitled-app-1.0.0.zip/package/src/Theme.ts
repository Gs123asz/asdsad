import React from "react";

import { useTheme, ThemeProvider, createTheme } from '@mui/material/styles';
import { deepOrange, purple, grey} from "@mui/material/colors"

export const darkTheme = createTheme({
    palette: {
      mode: 'dark',
      background:{
        paper:grey[900],
        default:grey[900]
      },
      divider:grey[50],
      secondary: {
        main: purple[500],
      },
    },
});

export const lightTheme = createTheme({
    palette: {
        mode: 'light',
        secondary: {
            main: deepOrange[400],
          },
    },
    
});

export const isDarkTheme = (): boolean => useTheme().palette.mode === "dark";